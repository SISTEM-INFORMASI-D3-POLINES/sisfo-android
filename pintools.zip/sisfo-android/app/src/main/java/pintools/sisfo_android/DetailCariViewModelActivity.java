package pintools.sisfo_android;

public class DetailCariViewModelActivity {
}
