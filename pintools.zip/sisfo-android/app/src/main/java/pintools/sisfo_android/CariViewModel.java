package pintools.sisfo_android;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.google.gson.annotations.SerializedName;
import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

import java.time.Year;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;

public class CariViewModel extends ViewModel {

    private static final String BASE_URL = "http://192.168.1.3";
    private static final String FULL_URL = BASE_URL+"/android_register_login/";

    class Tools {
        @SerializedName("id_tools")
        private String id_tools;
        @SerializedName("nama_tools")
        private String nama_tools;
        @SerializedName("merk")
        private String merk;
        @SerializedName("type")
        private String type;
        @SerializedName("bahan")
        private String bahan;
        @SerializedName("spesifikasi")
        private Text spesifikasi;
        @SerializedName("satuan")
        private String satuan;
        @SerializedName("stok_akhir")
        private int stok_akhir;
        @SerializedName("stok_awal")
        private int stok_awal;
        @SerializedName("thn_masuk")
        private Year thn_masuk;
        @SerializedName("desk_tools")
        private String desk_tools;
        @SerializedName("lokasi_tools")
        private String lokasi_tools;
        @SerializedName("image_tools")
        private String image_tools;


        public Tools(String id_tools, String nama_tools, String merk, String type, String bahan, Text spesifikasi, String satuan, int stok_akhir, int stok_awal, Year thn_masuk, String desk_tools, String lokasi_tools, String image_tools) {
            this.id_tools = id_tools;
            this.nama_tools = nama_tools;
            this.merk = merk;
            this.type=type;
            this.bahan=bahan;
            this.spesifikasi=spesifikasi;
            this.satuan=satuan;
            this.stok_akhir=stok_akhir;
            this.stok_awal=stok_awal;
            this.thn_masuk=thn_masuk;
            this.desk_tools=desk_tools;
            this.lokasi_tools=lokasi_tools;
            this.image_tools=image_tools;
        }

        /*
         *GETTERS AND SETTERS
         */
        public String getId_tools() {
            return id_tools;
        }
        public void setId(String id_tools) {
            this.id_tools = id_tools;
        }
        public String getNama_tools() {
            return nama_tools;
        }
        public String getMerk() {
            return merk;
        }
        public String getType() {
            return type;
        }
        public String getBahan() {
            return bahan;
        }
        public Text getSpesifikasi() {
            return spesifikasi;
        }
        public String getSatuan() {
            return satuan;
        }
        public int getStok_akhir() {
            return stok_akhir;
        }
        public int getStok_awal() {
            return stok_awal;
        }
        public Year getThn_masuk() {
            return thn_masuk;
        }
        public String getDesk_tools() {
            return desk_tools;
        }
        public String getLokasi_tools() {
            return lokasi_tools;
        }
        public String getImage_tools() {
            return image_tools;
        }

        @Override
        public String toString() {
            return nama_tools;
        }
    }

    interface MyAPIService {

        @GET("/PHP/cari_alat/tools")
        Call<List<Tools>> getTools();
    }

    static class RetrofitClientInstance {
        private static Retrofit retrofit;

        public static Retrofit getRetrofitInstance() {
            if (retrofit == null) {
                retrofit = new Retrofit.Builder()
                        .baseUrl(BASE_URL)
                        .addConverterFactory(GsonConverterFactory.create())
                        .build();
            }
            return retrofit;
        }
    }

    class FilterHelper extends Filter {
        private List<Tools> currentList;
        private ListViewAdapter adapter;
        private Context c;

        public FilterHelper(List<Tools> currentList, ListViewAdapter adapter, Context c) {
            this.currentList = currentList;
            this.adapter = adapter;
            this.c=c;
        }

        //filtering

        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            FilterResults filterResults=new FilterResults();

            if(constraint != null && constraint.length()>0)
            {
                //CHANGE TO UPPER
                constraint=constraint.toString().toUpperCase();

                //HOLD FILTERS WE FIND
                ArrayList<Tools> foundFilters=new ArrayList<>();

                Tools tools=null;

                //ITERATE CURRENT LIST
                for (int i=0;i<currentList.size();i++)
                {
                    tools= currentList.get(i);

                    //SEARCH
                    if(tools.getNama_tools().toUpperCase().contains(constraint) )
                    {
                        //ADD IF FOUND
                        foundFilters.add(tools);
                    }
                }

                //SET RESULTS TO FILTER LIST
                filterResults.count=foundFilters.size();
                filterResults.values=foundFilters;
            }else
            {
                //NO ITEM FOUND.LIST REMAINS INTACT
                filterResults.count=currentList.size();
                filterResults.values=currentList;
            }

            //RETURN RESULTS
            return filterResults;
        }

        @Override
        protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
            adapter.setTools((ArrayList<Tools>) filterResults.values);
            adapter.refresh();

        }
    }
    class ListViewAdapter extends BaseAdapter implements Filterable {

        private List<Tools> tools;
        private Context context;
        private List<Tools> currentList;
        private FilterHelper filterHelper;

        public ListViewAdapter(Context context,List<Tools> tools){
            this.context = context;
            this.tools = tools;
            this.currentList=tools;
        }



        @Override
        public int getCount() {
            return tools.size();
        }

        @Override
        public Object getItem(int pos) {
            return tools.get(pos);
        }

        @Override
        public long getItemId(int pos) {
            return pos;
        }

        @Override
        public View getView(int position, View view, ViewGroup viewGroup) {
            if(view==null)
            {
                view= LayoutInflater.from(context).inflate(R.layout.cari_list_row,viewGroup,false);
            }

            TextView nameTxt = view.findViewById(R.id.tools_name);
            TextView txtjumlahTools = view.findViewById(R.id.jumlah_tools);
            TextView txtLokasi = view.findViewById(R.id.lokasi_tools);
            ImageView spacecraftImageView = view.findViewById(R.id.image_tools);

            final Tools thisTools= tools.get(position);

            nameTxt.setText(thisTools.getNama_tools());
            txtjumlahTools.setText(thisTools.getStok_awal()+"/"+thisTools.getStok_akhir());
            txtLokasi.setText(thisTools.getLokasi_tools());


            if(thisTools.getImage_tools() != null && thisTools.getImage_tools().length()>0)
            {
                Picasso.get().load(FULL_URL+"/images/"+thisTools.getImage_tools()).placeholder(R.drawable.placeholder).into(spacecraftImageView);
            }else {
                Toast.makeText(context, "Empty Image URL", Toast.LENGTH_LONG).show();
                Picasso.get().load(R.drawable.placeholder).into(spacecraftImageView);
            }

            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText(context, thisTools.getNama_tools(), Toast.LENGTH_SHORT).show();
                    String techExists="";

                    String[] tools = {
                            thisTools.getNama_tools(),
                            String.valueOf(thisTools.getStok_akhir()),
                            thisTools.getLokasi_tools(),
                            FULL_URL+"/images/"+thisTools.getImage_tools()
                    };
                    openDetailActivity(tools);
                }
            });

            return view;
        }
        private void openDetailActivity(String[] data) {
            Intent intent = new Intent(CariViewModel.this, DetailCariViewModelActivity.class);
            intent.putExtra("NAME_TOOLS", data[1]);
            intent.putExtra("MERK", data[2]);
            intent.putExtra("TYPE", data[3]);
            intent.putExtra("BAHAN", data[4]);
            intent.putExtra("SPESIFIKASI", data[5]);
            intent.putExtra("SATUAN", data[6]);
            intent.putExtra("STOK_AWAL", data[7]);
            intent.putExtra("STOK_AKHIR", data[8]);
            intent.putExtra("THN_MASUK", data[9]);
            intent.putExtra("KONDISI", data[10]);
            intent.putExtra("LOKASI_TOOLS", data[11]);
            intent.putExtra("IMAGE_TOOLS", data[12]);
            context.startActivity(CariViewModel.this);
        }

        public void setTools(ArrayList<Tools> filteredTools)
        {
            this.tools=filteredTools;
        }
        @Override
        public Filter getFilter() {
            if(filterHelper==null)
            {
                filterHelper=new FilterHelper(currentList,this,context);
            }
            return filterHelper;
        }
        public void refresh(){
            notifyDataSetChanged();
        }
    }

    private CariViewModel.ListViewAdapter adapter;
    private ListView mListView;
    private ProgressBar mProgressBar;
    private SearchView mSearchView;

    private void initializeWidgets(){
        mListView = mListView.findViewById(R.id.Cari_ListView);
        mProgressBar= mProgressBar.findViewById(R.id.mProgressBar);
        mProgressBar.setIndeterminate(true);
        mProgressBar.setVisibility(View.VISIBLE);
        mSearchView= mSearchView.findViewById(R.id.AlatSearch);
        mSearchView.setIconified(true);
    }

    private void populateListView(List<Tools> toolsList) {
        adapter = new ListViewAdapter(this, toolsList);
        mListView.setAdapter(adapter);
    }


    private MutableLiveData<String> mText;

    public CariViewModel() {

        this.initializeWidgets();
        mText = new MutableLiveData<>();
        mText.setValue("This is dashboard fragment");
        MyAPIService myAPIService = RetrofitClientInstance.getRetrofitInstance().create(MyAPIService.class);

        Call<List<Tools>> call = myAPIService.getTools();
        call.enqueue(new Callback<List<Tools>>() {

            @Override
            public void onResponse(Call<List<Tools>> call, Response<List<Tools>> response) {
                mProgressBar.setVisibility(View.GONE);
                populateListView(response.body());
            }
            @Override
            public void onFailure(Call<List<Tools>> call, Throwable throwable) {
                mProgressBar.setVisibility(View.GONE);
                Toast.makeText(CariViewModel.this, "Fail because"+throwable.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

        mSearchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                adapter.getFilter().filter(s);
                return false;
            }
            @Override
            public boolean onQueryTextChange(String query) {
                adapter.getFilter().filter(query);
                return false;
            }
        });

    }

    public LiveData<String> getText() {
        return mText;
    }


}